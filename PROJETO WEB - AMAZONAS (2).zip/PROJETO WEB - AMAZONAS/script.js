//MACACAO
function soma1() {
	var qtd = document.getElementById("mudarQtd1").value;
	qtd++
	document.getElementById("mudarQtd1").value = qtd;
	valorProduto1()
	valorTotal()
}

function subtracao1() {
	var qtd = document.getElementById("mudarQtd1").value;
	qtd--
	document.getElementById("mudarQtd1").value = qtd;
	valorProduto1()
	valorTotal()
}

function valorProduto1(){
	var qtd = document.getElementById("mudarQtd1").value;
	var preco = document.getElementById("priceValor1").value;
	document.getElementById("priceValor1").value = qtd*3000;
	
}


//LUVA
function soma2() {
	var qtd = document.getElementById("mudarQtd2").value;
	qtd++
	document.getElementById("mudarQtd2").value = qtd;
	valorProduto2()
	valorTotal()
}

function subtracao2() {
	var qtd = document.getElementById("mudarQtd2").value;
	qtd--
	document.getElementById("mudarQtd2").value = qtd;
	valorProduto2()
	valorTotal()
}

function valorProduto2(){
	var qtd = document.getElementById("mudarQtd2").value;
	var preco = document.getElementById("priceValor2").value;
	document.getElementById("priceValor2").value = qtd*300;
	
}


//COLETE
function soma3() {
	var qtd = document.getElementById("mudarQtd3").value;
	qtd++
	document.getElementById("mudarQtd3").value = qtd;
	valorProduto3()
	valorTotal()
}

function subtracao3() {
	var qtd = document.getElementById("mudarQtd3").value;
	qtd--
	document.getElementById("mudarQtd3").value = qtd;
	valorProduto3()
	valorTotal()
}

function valorProduto3(){
	var qtd = document.getElementById("mudarQtd3").value;
	var preco = document.getElementById("priceValor3").value;
	document.getElementById("priceValor3").value = qtd*4000;
	
}



//CAPACETE
function soma4() {
	var qtd = document.getElementById("mudarQtd4").value;
	qtd++
	document.getElementById("mudarQtd4").value = qtd;
	valorProduto4()
	valorTotal()
}

function subtracao4() {
	var qtd = document.getElementById("mudarQtd4").value;
	qtd--
	document.getElementById("mudarQtd4").value = qtd;
	valorProduto4()
	valorTotal()
}

function valorProduto4(){
	var qtd = document.getElementById("mudarQtd4").value;
	var preco = document.getElementById("priceValor4").value;
	document.getElementById("priceValor4").value = qtd*3000;
	
}



//CALÇA ALPINESTARS
function soma5() {
	var qtd = document.getElementById("mudarQtd5").value;
	qtd++
	document.getElementById("mudarQtd5").value = qtd;
	valorProduto5()
	valorTotal()
}

function subtracao5() {
	var qtd = document.getElementById("mudarQtd5").value;
	qtd--
	document.getElementById("mudarQtd5").value = qtd;
	valorProduto5()
	valorTotal()
}

function valorProduto5(){
	var qtd = document.getElementById("mudarQtd5").value;
	var preco = document.getElementById("priceValor5").value;
	document.getElementById("priceValor5").value = qtd*2000;
	
}


function valorTotal(){
	var preco1 = document.getElementById("priceValor1").value;
	var preco2 = document.getElementById("priceValor2").value;
	var preco3 = document.getElementById("priceValor3").value;
	var preco4 = document.getElementById("priceValor4").value;
	var preco5 = document.getElementById("priceValor5").value;
	document.getElementById("valorTotal").value = parseInt(preco1)+parseInt(preco2)+parseInt(preco3)+parseInt(preco4)+parseInt(preco5);

}



function pedidoGerar(){
	document.getElementById("numeroPedido").value = Math.floor(Math.random()*10000000000000000) - 100;
	
}




//CEP
function limpa_formulário_cep() {
	//Limpa valores do formulário de cep.
	document.getElementById('rua').value=("");
	document.getElementById('bairro').value=("");
	document.getElementById('cidade').value=("");
	document.getElementById('uf').value=("");
	document.getElementById('frete').value=("");
	document.getElementById('entrega').value=("");
	

}

function meu_callback(conteudo) {
if (!("erro" in conteudo)) {
	//Atualiza os campos com os valores.
	document.getElementById('rua').value=(conteudo.logradouro);
	document.getElementById('bairro').value=(conteudo.bairro);
	document.getElementById('cidade').value=(conteudo.localidade);
	document.getElementById('uf').value=(conteudo.uf);
	document.getElementById('frete').value=("R$ 25,00");
	document.getElementById('entrega').value=("15 dias");

} //end if.
else {
	//CEP não Encontrado.
	limpa_formulário_cep();
	alert("CEP não encontrado.");
}
}

function pesquisacep(valor) {

//Nova variável "cep" somente com dígitos.
var cep = valor.replace(/\D/g, '');

//Verifica se campo cep possui valor informado.
if (cep != "") {

	//Expressão regular para validar o CEP.
	var validacep = /^[0-9]{8}$/;

	//Valida o formato do CEP.
	if(validacep.test(cep)) {

		//Preenche os campos com "..." enquanto consulta webservice.
		document.getElementById('rua').value="...";
		document.getElementById('bairro').value="...";
		document.getElementById('cidade').value="...";
		document.getElementById('uf').value="...";
		document.getElementById('frete').value="...";

		//Cria um elemento javascript.
		var script = document.createElement('script');

		//Sincroniza com o callback.
		script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

		//Insere script no documento e carrega o conteúdo.
		document.body.appendChild(script);

	} //end if.
	else {
		//cep é inválido.
		limpa_formulário_cep();
		alert("Formato de CEP inválido.");
	}
} //end if.
else {
	//cep sem valor, limpa formulário.
	limpa_formulário_cep();
}
};

function Excluir1() {
	document.getElementById('priceValor1').value="0";
	var display = document.getElementById("produto1").style.display;

	if(display == "none")
		document.getElementById("produto1").style.display = 'block';
	else
		document.getElementById("produto1").style.display = 'none';

		valorTotal()
}

function Excluir2() {
	document.getElementById('priceValor2').value="0";
	var display = document.getElementById("produto2").style.display;
	if(display == "none")
		document.getElementById("produto2").style.display = 'block';
	else
		document.getElementById("produto2").style.display = 'none';

		valorTotal()
}

function Excluir3() {
	document.getElementById('priceValor3').value="0";
	var display = document.getElementById("produto3").style.display;
	if(display == "none")
		document.getElementById("produto3").style.display = 'block';
	else
		document.getElementById("produto3").style.display = 'none';

		valorTotal()
}

function Excluir4() {
	document.getElementById('priceValor4').value="0";
	var display = document.getElementById("produto4").style.display;
	if(display == "none")
		document.getElementById("produto4").style.display = 'block';
	else
		document.getElementById("produto4").style.display = 'none';

		valorTotal()
}

function Excluir5() {
	document.getElementById('priceValor5').value="0";
	var display = document.getElementById("produto5").style.display;
	if(display == "none")
		document.getElementById("produto5").style.display = 'block';
	else
		document.getElementById("produto5").style.display = 'none';

		valorTotal()
}

window.onload = function CarregarFuncao() {
    valorTotal()
}


