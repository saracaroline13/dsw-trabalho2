let modelsJson = [
    {id:1, name:'Macacão X11', descricao:'Macacão X11', img:'./img/produtos/000009.jpg', price:[3000.00]},
    {id:2, name:'Luva X11 Impact 2 - Cano Longo', descricao:'Luva de couro impermeavel', img:'./img/produtos/000006.jpg', price:[300.00]},
    {id:3, name:'Colete X11', descricao:'Colete X11', img:'./img/produtos/000012.jpg',  price:[4000.00]},
    {id:4, name:'Capacete Norisk', descricao:'Capacete Norisk', img:'./img/produtos/000004.jpg',  price:[2500.00]},
    {id:5, name:'Calça Alpinestars', descricao:'Calça Alpinestars', img:'./img/produtos/000002.jpg',  price:[2000.00]}

];